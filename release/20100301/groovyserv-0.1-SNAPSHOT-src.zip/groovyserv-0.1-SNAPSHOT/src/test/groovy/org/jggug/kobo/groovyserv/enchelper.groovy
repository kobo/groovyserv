package org.jggug.kobo.groovyserv
println "あいうえお"
