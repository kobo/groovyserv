package org.jggug.kobo.groovyserv;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite(
				"Test for jp.co.nttdocomo.dojaonstar.converter");
		//$JUnit-BEGIN$
		suite.addTestSuite(DumpTest.class);
		suite.addTestSuite(EncodingTest.class);
		suite.addTestSuite(ExecTest.class);
		suite.addTestSuite(ExitTest.class);
		suite.addTestSuite(ThreadTest.class);
		//$JUnit-END$
		return suite;
	}

}
